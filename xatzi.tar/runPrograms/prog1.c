#include <stdio.h>

int main(void) {
  printf("This is the first program\n");
}
