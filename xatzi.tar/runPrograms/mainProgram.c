#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(void) {
  
  pid_t pid = fork();
  pid_t pid2;

  switch(pid) {
    case 0:
      pid2 = fork();
      switch(pid2) {
        case 0:
          execl("/usr/bin/gcc", "gcc", "-o", "prog1", "prog1.c", NULL);
          return 0;
        default:
          wait(NULL);
          execl("/usr/bin/gcc", "gcc", "-o", "prog2", "prog2.c", NULL);
          return 0;
      }
      break;
    default:
      wait(NULL);
  }
  pid = fork();
  switch(pid) {
    case 0:
      pid2 = fork();
      switch(pid2) {
        case 0:
          system("ls");
          execl("./prog1", "prog1", NULL);
          return 0;
        default:
          wait(NULL);
          execl("./prog2", "prog2", NULL);
          return 0;
      }
      break;
    default:
      wait(NULL);
      system("rm prog1 prog2");
  }
}
